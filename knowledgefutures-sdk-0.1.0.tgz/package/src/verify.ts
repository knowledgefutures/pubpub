import * as crypto from "node:crypto";

import type { KfSession } from "./types.js";

export type { KfSession };

// --- jwks / jwt verification ---

export interface JwksVerifierOptions {
  /** the kf-auth server URL to fetch JWKS from */
  issuerUrl: string;
  /** how long to cache the JWKS in ms (default: 1 hour) */
  cacheTtlMs?: number;
}

interface JwksKey {
  kid: string;
  kty: string;
  n: string;
  e: string;
  alg?: string;
  use?: string;
}

interface JwksCache {
  keys: JwksKey[];
  fetchedAt: number;
}

let jwksCache: JwksCache | null = null;

async function fetchJwks(issuerUrl: string): Promise<JwksKey[]> {
  const res = await fetch(`${issuerUrl}/api/auth/jwks`);

  if (!res.ok) {
    throw new Error(`failed to fetch JWKS: ${res.status}`);
  }

  const body = (await res.json()) as { keys: JwksKey[] };
  return body.keys;
}

async function getJwks(
  issuerUrl: string,
  cacheTtlMs: number,
): Promise<JwksKey[]> {
  const now = Date.now();
  const cacheValid = jwksCache && now - jwksCache.fetchedAt < cacheTtlMs;

  if (cacheValid && jwksCache) {
    return jwksCache.keys;
  }

  const keys = await fetchJwks(issuerUrl);

  jwksCache = { keys, fetchedAt: now };
  return keys;
}

function base64UrlToBuffer(base64url: string): Buffer {
  const base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
  return Buffer.from(base64, "base64");
}

async function verifyJwt(
  token: string,
  keys: JwksKey[],
): Promise<Record<string, unknown> | null> {
  const parts = token.split(".");

  if (parts.length !== 3) {
    return null;
  }

  const [headerB64, payloadB64, signatureB64] = parts as [
    string,
    string,
    string,
  ];

  const header = JSON.parse(
    base64UrlToBuffer(headerB64).toString(),
  ) as Record<string, unknown>;

  const kid = header["kid"] as string | undefined;
  const key = kid ? keys.find((k) => k.kid === kid) : keys[0];

  if (!key) {
    return null;
  }

  const publicKey = crypto.createPublicKey({
    key: {
      kty: key.kty,
      n: key.n,
      e: key.e,
    },
    format: "jwk",
  });

  const data = Buffer.from(`${headerB64}.${payloadB64}`);
  const signature = base64UrlToBuffer(signatureB64);

  const valid = crypto.verify(
    "sha256",
    data,
    { key: publicKey, padding: crypto.constants.RSA_PKCS1_PSS_PADDING },
    signature,
  );

  if (!valid) {
    return null;
  }

  const payload = JSON.parse(
    base64UrlToBuffer(payloadB64).toString(),
  ) as Record<string, unknown>;

  const now = Math.floor(Date.now() / 1000);
  const exp = payload["exp"] as number | undefined;

  if (exp && exp < now) {
    return null;
  }

  return payload;
}

/**
 * verifies a kf-auth JWT access token against the JWKS endpoint.
 * returns the decoded payload or null if invalid/expired.
 */
export async function verifyToken(
  issuerUrl: string,
  token: string,
  cacheTtlMs = 60 * 60 * 1000,
): Promise<Record<string, unknown> | null> {
  const keys = await getJwks(issuerUrl, cacheTtlMs);
  return verifyJwt(token, keys);
}

/**
 * verifies a kf-auth session by forwarding cookies to the auth server.
 * returns the session data or null if invalid/expired.
 */
export async function verifySession(
  authUrl: string,
  cookie: string,
): Promise<KfSession | null> {
  try {
    const res = await fetch(`${authUrl}/api/auth/get-session`, {
      headers: { cookie },
    });

    if (!res.ok) {
      return null;
    }

    const data = (await res.json()) as KfSession | null;

    if (!data?.user || !data?.session) {
      return null;
    }

    return data;
  } catch {
    return null;
  }
}
