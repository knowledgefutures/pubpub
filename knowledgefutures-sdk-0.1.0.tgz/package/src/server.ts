export interface KfServerSdkOptions {
  serverUrl: string;
  adminApiKey?: string;
}

export interface KfSignInResult {
  user: { id: string; email: string; name: string };
  token?: string;
}

export interface KfSignUpResult {
  user: { id: string; email: string; name: string };
  token?: string;
}

export interface KfImportUser {
  email: string;
  name: string;
  givenName?: string;
  familyName?: string;
  passwordHash: string;
  emailVerified: boolean;
}

export interface KfImportResult {
  email: string;
  id: string | null;
  status: "created" | "exists" | "error";
  error?: string;
}

export interface KfServerSdk {
  signIn: {
    email: (data: {
      email: string;
      password: string;
    }) => Promise<{ data?: KfSignInResult; error?: { message: string } }>;
  };

  signUp: {
    email: (data: {
      email: string;
      password: string;
      name: string;
      callbackURL?: string;
    }) => Promise<{ data?: KfSignUpResult; error?: { message: string } }>;
  };

  forgetPassword: (data: {
    email: string;
    redirectTo: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  resetPassword: (data: {
    newPassword: string;
    token: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  changePassword: (data: {
    currentPassword: string;
    newPassword: string;
    sessionToken: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  importUsers: (users: KfImportUser[]) => Promise<{ results: KfImportResult[] }>;

  deleteUser: (userId: string) => Promise<{ success: boolean }>;
}

export function createKfServerSdk(options: KfServerSdkOptions): KfServerSdk {
  const { serverUrl } = options;

  async function post<T>(
    path: string,
    body: unknown,
    headers?: Record<string, string>,
  ): Promise<T> {
    const res = await fetch(`${serverUrl}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...headers,
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "unknown error");

      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = null;
      }

      const message =
        parsed && typeof parsed === "object" && "message" in parsed
          ? (parsed as { message: string }).message
          : text;

      return { error: { message } } as T;
    }

    return res.json() as Promise<T>;
  }

  return {
    signIn: {
      email: (data) => post("/api/auth/sign-in/email", data),
    },

    signUp: {
      email: (data) => post("/api/auth/sign-up/email", data),
    },

    forgetPassword: (data) => post("/api/auth/forget-password", data),

    resetPassword: (data) => post("/api/auth/reset-password", data),

    changePassword: (data) =>
      post(
        "/api/auth/change-password",
        {
          currentPassword: data.currentPassword,
          newPassword: data.newPassword,
        },
        {
          Authorization: `Bearer ${data.sessionToken}`,
        },
      ),

    importUsers: (users) => post("/api/admin/import-users", { users }),

    deleteUser: async (userId) => {
      const res = await fetch(`${serverUrl}/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      });

      return { success: res.ok };
    },
  };
}
