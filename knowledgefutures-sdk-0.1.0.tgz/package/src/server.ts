export interface KfServerSdkOptions {
  serverUrl: string;
  adminApiKey?: string;
}

export interface KfSignInResult {
  user: { id: string; email: string; name: string };
  token?: string;
}

export interface KfSignUpResult {
  user: { id: string; email: string; name: string };
  token?: string;
}

export interface KfImportUser {
  email: string;
  name: string;
  givenName?: string;
  familyName?: string;
  passwordHash: string;
  emailVerified: boolean;
}

export interface KfImportResult {
  email: string;
  id: string | null;
  status: "created" | "exists" | "error";
  error?: string;
}

export interface KfServerSdk {
  signIn: {
    email: (data: {
      email: string;
      password: string;
    }) => Promise<{ data?: KfSignInResult; error?: { message: string } }>;
  };

  signUp: {
    email: (data: {
      email: string;
      password: string;
      name: string;
      callbackURL?: string;
    }) => Promise<{ data?: KfSignUpResult; error?: { message: string } }>;
  };

  forgetPassword: (data: {
    email: string;
    redirectTo: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  resetPassword: (data: {
    newPassword: string;
    token: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  changePassword: (data: {
    currentPassword: string;
    newPassword: string;
    sessionToken: string;
  }) => Promise<{ data?: unknown; error?: { message: string } }>;

  setPassword: (data: {
    userId: string;
    newPassword: string;
  }) => Promise<{ success: boolean; error?: string }>;

  importUsers: (users: KfImportUser[]) => Promise<{ results: KfImportResult[] }>;

  deleteUser: (userId: string) => Promise<{ success: boolean }>;
}

export function createKfServerSdk(options: KfServerSdkOptions): KfServerSdk {
  const { serverUrl, adminApiKey } = options;

  function adminHeaders(): Record<string, string> {
    if (!adminApiKey) {
      return {};
    }

    return { Authorization: `Bearer ${adminApiKey}` };
  }

  async function post<T>(
    path: string,
    body: unknown,
    headers?: Record<string, string>,
  ): Promise<T> {
    const res = await fetch(`${serverUrl}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // better-auth rejects POST requests without a recognized origin (csrf protection).
        // since this is a trusted server-to-server call, we set origin to the auth server itself.
        Origin: serverUrl,
        ...headers,
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "unknown error");

      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = null;
      }

      const message =
        parsed && typeof parsed === "object" && "message" in parsed
          ? (parsed as { message: string }).message
          : text;

      return { error: { message } } as T;
    }

    return res.json() as Promise<T>;
  }

  // better-auth returns auth results at the top level (e.g. { user, token }).
  // the sdk interface expects { data: { user } } / { error: { message } },
  // so we wrap successful responses.
  async function authPost<T>(path: string, body: unknown): Promise<T> {
    const raw = await post<Record<string, unknown>>(path, body);

    if ("error" in raw) {
      return raw as T;
    }

    return { data: raw } as T;
  }

  return {
    signIn: {
      email: (data) => authPost("/api/auth/sign-in/email", data),
    },

    signUp: {
      email: (data) => authPost("/api/auth/sign-up/email", data),
    },

    forgetPassword: (data) => authPost("/api/auth/request-password-reset", data),

    resetPassword: (data) => authPost("/api/auth/reset-password", data),

    changePassword: (data) =>
      post(
        "/api/auth/change-password",
        {
          currentPassword: data.currentPassword,
          newPassword: data.newPassword,
        },
        {
          Authorization: `Bearer ${data.sessionToken}`,
        },
      ),

    setPassword: async (data) => {
      const res = await fetch(`${serverUrl}/api/admin/users/${data.userId}/set-password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Origin: serverUrl,
          ...adminHeaders(),
        },
        body: JSON.stringify({ newPassword: data.newPassword }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        return { success: false, error: (body as any).error ?? "unknown error" };
      }

      return { success: true };
    },

    importUsers: (users) => post("/api/admin/import-users", { users }, adminHeaders()),

    deleteUser: async (userId) => {
      const res = await fetch(`${serverUrl}/api/admin/users/${userId}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Origin: serverUrl,
          ...adminHeaders(),
        },
      });

      return { success: res.ok };
    },
  };
}
