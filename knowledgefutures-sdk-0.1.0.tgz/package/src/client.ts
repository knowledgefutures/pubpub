import { createAuthClient } from "better-auth/client";
import { emailOTPClient, genericOAuthClient } from "better-auth/client/plugins";

import type { KfSdkOptions } from "./types.js";

export function createBetterAuthClient(options: KfSdkOptions) {
  return createAuthClient({
    baseURL: options.serverUrl,
    plugins: [genericOAuthClient(), emailOTPClient()],
  });
}

export type BetterAuthClient = ReturnType<typeof createBetterAuthClient>;
