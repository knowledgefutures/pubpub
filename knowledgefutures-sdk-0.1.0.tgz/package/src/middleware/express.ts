import type { Request, Response, NextFunction } from "express";

import { verifySession, verifyToken } from "../verify.js";
import type { KfSession, JwksVerifierOptions } from "../verify.js";

export type { KfSession, JwksVerifierOptions };

declare global {
  namespace Express {
    interface Request {
      kfUser?: KfSession["user"];
      kfSession?: KfSession["session"];
      kfJwtPayload?: Record<string, unknown>;
    }
  }
}

export interface SessionMiddlewareOptions {
  /** the kf-auth server URL, e.g. "http://localhost:3000" */
  authUrl: string;
}

/**
 * express middleware that verifies kf-auth sessions via cookie forwarding.
 * sets `req.kfUser` and `req.kfSession` on success.
 */
export function kfSessionMiddleware(options: SessionMiddlewareOptions) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const cookie = req.headers.cookie ?? "";
    const session = await verifySession(options.authUrl, cookie);

    if (!session) {
      res.status(401).json({ error: "unauthorized" });
      return;
    }

    req.kfUser = session.user;
    req.kfSession = session.session;
    next();
  };
}

/**
 * express middleware that validates kf-auth JWT access tokens.
 * extracts the bearer token from the Authorization header and sets
 * `req.kfJwtPayload` on success.
 */
export function kfAuthMiddleware(options: JwksVerifierOptions) {
  const cacheTtlMs = options.cacheTtlMs ?? 60 * 60 * 1000;

  return async (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;

    if (!authHeader?.startsWith("Bearer ")) {
      res.status(401).json({ error: "unauthorized" });
      return;
    }

    const token = authHeader.slice(7);

    try {
      const payload = await verifyToken(options.issuerUrl, token, cacheTtlMs);

      if (!payload) {
        res.status(401).json({ error: "invalid token" });
        return;
      }

      req.kfJwtPayload = payload;
    } catch {
      res.status(401).json({ error: "token verification failed" });
      return;
    }

    next();
  };
}
