let _baseUrl = "";

export function setBaseUrl(url: string) {
  _baseUrl = url.replace(/\/$/, "");
}

interface FetcherOptions {
  url: string;
  method: string;
  headers?: Record<string, string>;
  body?: unknown;
  signal?: AbortSignal;
}

export async function kfFetcher<T>(options: FetcherOptions): Promise<T> {
  const url = `${_baseUrl}${options.url}`;

  const headers: Record<string, string> = {
    "content-type": "application/json",
    ...options.headers,
  };

  const res = await fetch(url, {
    method: options.method,
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
    signal: options.signal,
    credentials: "include",
  });

  if (!res.ok) {
    const errorBody = await res.text().catch(() => "");
    throw new Error(`${res.status}: ${errorBody}`);
  }

  const contentType = res.headers.get("content-type") ?? "";

  if (contentType.includes("application/json")) {
    return res.json() as Promise<T>;
  }

  return res.text() as unknown as T;
}
