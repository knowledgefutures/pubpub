import type { KfSession } from "../types.js";

export type { KfSession };

export interface KfMiddlewareOptions {
  /** the kf-auth server URL, e.g. "http://localhost:3000" */
  authUrl: string;
  /** paths that require authentication (default: all paths) */
  protectedPaths?: string[];
  /** where to redirect unauthenticated users (default: "/sign-in") */
  signInPath?: string;
}

/**
 * creates a next.js middleware function that verifies kf-auth sessions.
 * uses standard fetch (edge-compatible) to forward cookies to the auth server.
 *
 * usage in middleware.ts:
 *   export default createKfMiddleware({ authUrl: "..." })
 */
export function createKfMiddleware(options: KfMiddlewareOptions) {
  const signInPath = options.signInPath ?? "/sign-in";

  return async (request: Request) => {
    const { NextResponse } = await import("next/server.js");

    const url = new URL(request.url);
    const isProtected = options.protectedPaths
      ? options.protectedPaths.some((p) => url.pathname.startsWith(p))
      : true;

    if (!isProtected) {
      return NextResponse.next();
    }

    const cookie = request.headers.get("cookie") ?? "";
    const session = await verifySessionFetch(options.authUrl, cookie);

    if (!session) {
      const signInUrl = new URL(signInPath, request.url);
      signInUrl.searchParams.set("redirect", url.pathname);
      return NextResponse.redirect(signInUrl);
    }

    const headers = new Headers(request.headers);
    headers.set("x-kf-user-id", session.user.id);
    headers.set("x-kf-user-email", session.user.email);

    return NextResponse.next({ request: { headers } });
  };
}

export interface WithAuthOptions {
  /** the kf-auth server URL */
  authUrl: string;
}

/**
 * wraps a next.js api route handler to require authentication.
 * injects the session into the request via x-kf-* headers, or returns 401.
 *
 * works with both pages router and app router api routes.
 */
export function withAuth(
  options: WithAuthOptions,
  handler: (request: Request, context: { session: KfSession }) => Response | Promise<Response>,
) {
  return async (request: Request) => {
    const cookie = request.headers.get("cookie") ?? "";
    const session = await verifySessionFetch(options.authUrl, cookie);

    if (!session) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      });
    }

    return handler(request, { session });
  };
}

// edge-compatible session verification using standard fetch
async function verifySessionFetch(authUrl: string, cookie: string): Promise<KfSession | null> {
  try {
    const res = await fetch(`${authUrl}/api/auth/get-session`, {
      headers: { cookie },
    });

    if (!res.ok) {
      return null;
    }

    const data = (await res.json()) as KfSession | null;

    if (!data?.user || !data?.session) {
      return null;
    }

    return data;
  } catch {
    return null;
  }
}
