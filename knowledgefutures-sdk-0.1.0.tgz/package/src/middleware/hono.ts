import type { Context, MiddlewareHandler } from "hono";

import { verifySession, verifyToken } from "../verify.js";
import type { KfSession, JwksVerifierOptions } from "../verify.js";

export type { KfSession, JwksVerifierOptions };

export interface SessionMiddlewareOptions {
  /** the kf-auth server URL, e.g. "http://localhost:3000" */
  authUrl: string;
}

/**
 * hono middleware that verifies kf-auth sessions via cookie forwarding.
 * sets `c.set("session", session)` and `c.set("user", user)` on success.
 */
export function kfSessionMiddleware(
  options: SessionMiddlewareOptions,
): MiddlewareHandler {
  return async (c: Context, next) => {
    const cookie = c.req.header("cookie") ?? "";
    const session = await verifySession(options.authUrl, cookie);

    if (!session) {
      return c.json({ error: "unauthorized" }, 401);
    }

    c.set("session", session.session);
    c.set("user", session.user);
    await next();
  };
}

/**
 * hono middleware that validates kf-auth JWT access tokens.
 * extracts the bearer token from the Authorization header,
 * verifies it against the kf-auth JWKS endpoint, and sets
 * `c.set("jwtPayload", payload)` on success.
 */
export function kfAuthMiddleware(
  options: JwksVerifierOptions,
): MiddlewareHandler {
  const cacheTtlMs = options.cacheTtlMs ?? 60 * 60 * 1000;

  return async (c: Context, next) => {
    const authHeader = c.req.header("authorization");

    if (!authHeader?.startsWith("Bearer ")) {
      return c.json({ error: "unauthorized" }, 401);
    }

    const token = authHeader.slice(7);

    try {
      const payload = await verifyToken(options.issuerUrl, token, cacheTtlMs);

      if (!payload) {
        return c.json({ error: "invalid token" }, 401);
      }

      c.set("jwtPayload", payload);
    } catch {
      return c.json({ error: "token verification failed" }, 401);
    }

    await next();
  };
}
