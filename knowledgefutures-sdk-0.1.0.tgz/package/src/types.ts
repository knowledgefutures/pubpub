export interface KfUser {
  id: string;
  email: string;
  emailVerified: boolean;
  name: string;
  givenName?: string;
  familyName?: string;
  slug?: string;
  image?: string;
  role: string;
  banned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface KfSdkOptions {
  /** the base URL of the kf-auth server, e.g. "https://auth.example.com" */
  serverUrl: string;
}

export interface KfSession {
  user: {
    id: string;
    email: string;
    name: string;
    emailVerified: boolean;
    image?: string | null;
    role?: string;
    [key: string]: unknown;
  };
  session: {
    id: string;
    token: string;
    expiresAt: string;
    [key: string]: unknown;
  };
}
