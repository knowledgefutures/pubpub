import { createBetterAuthClient } from "./client.js";
import type { BetterAuthClient } from "./client.js";
import { setBaseUrl } from "./generated/fetcher.js";
import type { KfSdkOptions } from "./types.js";

export type { KfUser, KfSdkOptions, KfSession } from "./types.js";
export { verifySession, verifyToken } from "./verify.js";
export type { JwksVerifierOptions } from "./verify.js";

export interface KfSdk {
  signIn: {
    email: (data: { email: string; password: string }) => Promise<any>;
    social: (data: { provider: string; callbackURL: string; newUserCallbackURL?: string }) => Promise<any>;
  };

  signUp: {
    email: (data: { email: string; password: string; name: string; callbackURL?: string }) => Promise<any>;
  };

  signOut: () => Promise<any>;
  getSession: () => Promise<any>;
  updateUser: (data: Record<string, unknown>) => Promise<any>;
  forgetPassword: (data: { email: string; redirectTo: string }) => Promise<any>;
  resetPassword: (data: { newPassword: string; token: string }) => Promise<any>;

  /** the underlying better-auth client, for advanced use cases */
  _client: BetterAuthClient;
}

export function createKfSdk(options: KfSdkOptions): KfSdk {
  setBaseUrl(options.serverUrl);
  const client = createBetterAuthClient(options);

  return {
    signIn: {
      email: (data) => client.signIn.email(data),
      social: (data) =>
        client.signIn.social({
          provider: data.provider as any,
          callbackURL: data.callbackURL,
          newUserCallbackURL: data.newUserCallbackURL,
        }),
    },

    signUp: {
      email: (data) =>
        client.signUp.email({
          email: data.email,
          password: data.password,
          name: data.name,
          callbackURL: data.callbackURL,
        }),
    },

    signOut: () => client.signOut(),
    getSession: () => client.getSession(),
    updateUser: (data) => client.updateUser(data as any),
    forgetPassword: (data) => (client as any).forgetPassword(data),
    resetPassword: (data) => (client as any).resetPassword(data),

    _client: client,
  };
}
